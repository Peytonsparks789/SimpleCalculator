package com.example.calculatorapp;

import 	androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import java.lang.*;
import java.lang.Math;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;


public class MainActivity extends AppCompatActivity {
    EditText firstval,secondval;
    TextView result;
    Button addition,subtract,divide,multiply, sqrt, squared, tooltip;
    ImageButton settings;
    Toast toast;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firstval = findViewById(R.id.first_num);
        secondval = findViewById(R.id.second_num);
        addition = findViewById(R.id.add);
        subtract = findViewById(R.id.sub);
        divide = findViewById(R.id.div);
        multiply = findViewById(R.id.times);
        sqrt = findViewById(R.id.sqrrt);
        squared = findViewById(R.id.square);
        result = findViewById(R.id.result);
        tooltip = findViewById(R.id.tooltip);
        settings = (ImageButton) findViewById(R.id.toggle);

        settings.setOnClickListener(view -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle(getResources().getString(R.string.hide_extras));
            builder.setPositiveButton(getResources().getString(R.string.hide_button), (dialog, which) -> {
                hidebox();
                dialog.dismiss();
            });
            AlertDialog diag = builder.create();
            diag.show();
        });
    }
    public void tooltip(View view) {
        AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
        alertDialog.setTitle(getResources().getString(R.string.tooltip));
        alertDialog.setMessage(getResources().getString(R.string.newline) + getResources().getString(R.string.Header1) + getResources().getString(R.string.par1)
                + getResources().getString(R.string.Header2) + getResources().getString(R.string.par2)
                + getResources().getString(R.string.Header3) + getResources().getString(R.string.par3)
                + getResources().getString(R.string.par4));
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK", (dialog, which) -> dialog.dismiss());
        alertDialog.show();
    }
    public boolean isAddable() {
        try {
            Double.parseDouble(firstval.getText().toString());
            Double.parseDouble(secondval.getText().toString());
            return false;
        }
        catch (NumberFormatException nfe) {
            return true;
        }
    }
    public boolean isNumeric(TextView strNum) {
        try {
            Double.parseDouble(strNum.getText().toString());
            return true;
        }
        catch (NumberFormatException e) {
            return false;
        }
    }
    public void square(View view) {
        if (isNumeric(result)) {
            double val = Double.parseDouble(result.getText().toString());
            val = Math.pow(val, 2);
            String value = String.valueOf(val);
            result.setText(value);
        }
        else {
            toastmsg(getResources().getString(R.string.error));
        }
    }
    public void sqrrt(View view) {
        if (isNumeric(result)) {
            double val = Double.parseDouble(result.getText().toString());
            val = Math.sqrt(val);
            String value = String.valueOf(val);
            result.setText(value);
        }
        else {
            toastmsg(getResources().getString(R.string.error));
        }
    }
    public void toastmsg (String Message){
        if (toast != null) {
            toast.cancel();
        }
        toast = Toast.makeText(MainActivity.this,Message,Toast.LENGTH_LONG);
        toast.show();
    }
    @SuppressLint("SetTextI18n")
    public void add(View view) {
        String first_num = firstval.getText().toString();
        String second_num = secondval.getText().toString();
        if (isAddable()) {
            toastmsg(getResources().getString(R.string.error));
        }
        else {
            double x = Double.parseDouble(first_num);
            double y = Double.parseDouble(second_num);
            result.setText(""+(x+y));
        }
    }
    @SuppressLint("SetTextI18n")
    public void sub(View view) {
        String first_num = firstval.getText().toString();
        String second_num = secondval.getText().toString();
        if (isAddable()) {
            toastmsg(getResources().getString(R.string.error));
        }
        else {
            double x = Double.parseDouble(first_num);
            double y = Double.parseDouble(second_num);
            result.setText(""+(x-y));
        }
    }
    @SuppressLint("SetTextI18n")
    public void div(View view) {
        String first_num = firstval.getText().toString();
        String second_num = secondval.getText().toString();
        if (isAddable()) {
            toastmsg(getResources().getString(R.string.error));
        }
        else {
            double x = Double.parseDouble(first_num);
            double y = Double.parseDouble(second_num);
            result.setText(""+(x/y));
        }
    }
    @SuppressLint("SetTextI18n")
    public void times(View view) {
        String first_num = firstval.getText().toString();
        String second_num = secondval.getText().toString();
        if (isAddable()) {
            toastmsg(getResources().getString(R.string.error));
        }
        else {
            double x = Double.parseDouble(first_num);
            double y = Double.parseDouble(second_num);
            result.setText(""+(x*y));
        }
    }
    public void reset(View view) {
        result.setText(null);
        firstval.setText(null);
        secondval.setText(null);
    }
    public void hidebox(){
        if (findViewById(R.id.toggleview).getVisibility() == View.VISIBLE) {
            findViewById(R.id.toggleview).setVisibility(View.INVISIBLE);
            toastmsg(getResources().getString(R.string.toggleoff));
        } else {
            findViewById(R.id.toggleview).setVisibility(View.VISIBLE);
            toastmsg(getResources().getString(R.string.toggleon));
        }
    }
}